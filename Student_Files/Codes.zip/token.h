/*
PLEASE DO NOT CHANGE THIS FILE EXCEPT THE TOKEN LENGTH
*/
#define TOKEN_LENGTH X

struct Token{
	char token[TOKEN_LENGTH];	
	int count=0;
};
